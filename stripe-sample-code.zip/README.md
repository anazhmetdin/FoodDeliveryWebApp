# Accept a Payment

Build a simple checkout form to collect payment details. Included are some basic
build and run scripts you can use to start up the application.

## Running the sample

1. Build the server

~~~
dotnet restore
~~~

2. Run the server

~~~
dotnet run
~~~

3. Go to [http://localhost:4242/checkout.html](http://localhost:4242/checkout.html)